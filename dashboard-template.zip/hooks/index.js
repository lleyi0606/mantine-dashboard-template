import useFetchData from '@/hooks/useFetchData';

export { useFetchData };
