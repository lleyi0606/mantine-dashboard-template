# Mantine Analytics Dashboard

## Installation

### Prerequisites

- Node.js 18.0.0 or higher
- npm 8.0.0 or higher

### Steps

```bash
git clone https://github.com/design-sparx/mantine-analytics-dashboard.git
cd mantine-analytics-dashboard
npm install
npm run dev
```

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for full license text.