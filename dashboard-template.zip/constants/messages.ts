export const MESSAGES = [
  {
    id: '687725a3-5489-486e-9ffd-180df00f8e10',
    first_name: 'Egor',
    last_name: 'Thornebarrow',
    message:
      'Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue.',
  },
  {
    id: '75103d7a-b26b-4e1f-8d7e-2117867d05b8',
    first_name: 'Magdalen',
    last_name: 'Slessor',
    message:
      'In eleifend quam a odio. In hac habitasse platea dictumst. Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.',
  },
  {
    id: '08bff541-e731-445f-a2e1-7f08e3e30357',
    first_name: 'Bald',
    last_name: 'Vant',
    message:
      'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue. Vestibulum rutrum rutrum neque.',
  },
];
